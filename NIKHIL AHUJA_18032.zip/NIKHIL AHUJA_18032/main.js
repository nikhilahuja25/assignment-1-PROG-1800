/*script*/

var correctanswers = ["a", "b", "c", "c", "d", "b", "a", "c", "d", "a"];

function checker()
{
                var b=document.quiz.que1.value;
				var c=document.quiz.que2.value;
				var d=document.quiz.que3.value;
				var e=document.quiz.que4.value;
				var f=document.quiz.que5.value;
				var g=document.quiz.que6.value;
				var h=document.quiz.que7.value;
				var i=document.quiz.que8.value;
				var j=document.quiz.que9.value;
				var k=document.quiz.que10.value;
				var a=0;
				
				if(b=="a")
				{a++;}
				if(c=="b")
				{a++;}
				if(d=="c")
				{a++;}
				if(e=="c")
				{a++;}
				if(f=="d")
				{a++;}
				if(g=="b")
				{a++;}
				if(h=="a")
				{a++;}
				if(i=="c")
				{a++;}
				if(j=="d")
				{a++;}
				if(k=="a")
				{a++;}	
				
				if(a==10)
				{
					alert("YOU HAVE SCORED "+a+" EXCELLENT");
				}
				else if(a<5)
				{
					alert("YOU HAVE SCORED "+a+" WORK HARD");
				}
				else if(a>=5)
				{
					alert("YOU HAVE SCORED "+a+" GOOD PERFORMANCE");
				}
}

